# snake-ladder game 
# 100 - win

# 2 player
# list snake position (ep>sp)
# list ladder position (sp<ep)
# dice (1-6)

# print statement

# sp both 0,0
# board 100 - 10*10
# dice - run - random(1-6)

# Happy Flow: dice - roll - snake/ladder - 100 - winner
# EC - 99 - dice(>1) -- fail - invalid move

# 1-roll per player -- but scaleble
# 6 - 1-roll -- scalable

# board - N - scaleble
# dice - scalable

# Objects:
# player (name, curr_x)
# position (x)
# board (N)
# snake (sp(x), ep(x)) - sp>ep
# ladder (sp(x), ep(x))
# dice (1-6)

# Game

# multi player - win - remove