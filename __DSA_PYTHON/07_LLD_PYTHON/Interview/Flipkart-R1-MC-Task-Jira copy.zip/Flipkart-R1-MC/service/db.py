class DB:
    tasks = {}
    sprints = {}
    assinged_users = {}